import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { FloatingCTA } from "@/components/FloatingCTA";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-semibold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-full bg-foreground px-5 py-2.5 text-sm font-medium text-background transition-colors hover:bg-foreground/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Royal Art — Paintings, Wall Art & Frame Rentals" },
      { name: "description", content: "Premium paintings, home décor and frame rentals for homes, businesses and realtor staging across Canada." },
      { property: "og:title", content: "Royal Art — Paintings, Wall Art & Frame Rentals" },
      { name: "twitter:title", content: "Royal Art — Paintings, Wall Art & Frame Rentals" },
      { property: "og:description", content: "Premium paintings, home décor and frame rentals for homes, businesses and realtor staging across Canada." },
      { name: "twitter:description", content: "Premium paintings, home décor and frame rentals for homes, businesses and realtor staging across Canada." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/246ac903-52db-4dc5-84ad-d6d7a7538baa/id-preview-4c9e649f--8e646e9c-da8d-42fb-aa79-4ed5c3f175ff.lovable.app-1776741097522.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/246ac903-52db-4dc5-84ad-d6d7a7538baa/id-preview-4c9e649f--8e646e9c-da8d-42fb-aa79-4ed5c3f175ff.lovable.app-1776741097522.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <Outlet />
      </main>
      <SiteFooter />
      <FloatingCTA />
    </div>
  );
}
